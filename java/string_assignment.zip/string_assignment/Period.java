class Period{
    public static void main(String[] args) {
        String[] str = {"Santosh", "is", "a", "good", "Teacher"};
        String str1;
        str1 = String.join(" ",str) + '.';
        System.out.print(str1);
    }
}